// Enables use of `init` in Unity with .NET Framework
namespace System.Runtime.CompilerServices
{
    internal static class IsExternalInit { }
}
